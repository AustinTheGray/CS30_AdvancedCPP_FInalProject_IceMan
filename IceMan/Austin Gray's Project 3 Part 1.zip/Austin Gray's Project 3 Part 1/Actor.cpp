#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

//////////////////////////////////////
//       ACTOR
//////////////////////////////////////
StudentWorld* Actor::getWorld()
{
	return world;
}

//////////////////////////////////////
//       ICE
//////////////////////////////////////

void Ice::doSomething()
{

}




//////////////////////////////////////
//       ICEMAN
//////////////////////////////////////

int IceMan::getHealth()
{
	return hp;
}
int IceMan::getWater()
{
	return water;
}
int IceMan::getNuggets()
{
	return nuggets;
}
int IceMan::getSonar()
{
	return sonar;
}
void IceMan::doSomething()
{
	int key;
	if(getWorld()->getKey(key) == true)
	{
		switch (key)
		{
		case KEY_PRESS_LEFT:
			if (getDirection() != left)
				setDirection(left);
			moveTo(getX() - 1, getY());
			break;
		case KEY_PRESS_RIGHT:
			if (getDirection() != right)
				setDirection(right);
			moveTo(1 + getX(), getY());
			break;
		case KEY_PRESS_DOWN:
			if (getDirection() != down)
				setDirection(down);
			moveTo(getX(), getY() - 1);
			break;
		case KEY_PRESS_UP:
			if (getDirection() != up)
				setDirection(up);
			moveTo(getX(), 1 + getY());
			break;
		default:
			break;
		}
		CheckIceCollision();
	}
}

void IceMan::CheckIceCollision()
{
	auto ice = getWorld()->getIce();
	for (auto it = ice->begin(); it != ice->end(); ++it)
	{
		if ((*it)->getX() >= getX()
			&& (*it)->getX() <= getX() + 3
			&& (*it)->getY() >= getY()
			&& (*it)->getY() <= getY() + 3)
		{
			(*it)->setVisible(false);
			ice->erase(it);
			it = ice->begin();
			getWorld()->playSound(SOUND_DIG);
		}
	}
}