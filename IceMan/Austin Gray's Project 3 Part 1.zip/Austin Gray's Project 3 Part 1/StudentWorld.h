#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_
#include "Actor.h"
#include "GameWorld.h"
#include "GameConstants.h"
#include <vector>
#include <string>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
//class IceMan;
//class Ice;


class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
		: GameWorld(assetDir)
	{
	}

	virtual int init()
	{
		player = new IceMan(this);
		setUpIce();

		return GWSTATUS_CONTINUE_GAME;
	}

	virtual int move()
	{
		UpdateDisplayText();
		
		if (player->getHealth() > 0) 
		{
			player->doSomething();
			return GWSTATUS_CONTINUE_GAME;
		}	
		else {
			decLives();
			return GWSTATUS_PLAYER_DIED;
		}
	}

	virtual void cleanUp()
	{
		delete player;
		deleteIce();
	}
	void UpdateDisplayText();
	
	std::vector<Ice*>* getIce();
private:
	IceMan* player;
	std::vector<Ice*> ice;
	//std::vector<GraphObject*> actors;


	void setUpIce();
	void deleteIce();
};

#endif // STUDENTWORLD_H_
