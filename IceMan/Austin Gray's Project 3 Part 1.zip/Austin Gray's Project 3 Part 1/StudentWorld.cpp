#include "StudentWorld.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

void StudentWorld::UpdateDisplayText()
{
	std::string text;
	text = "Lvl: " + std::to_string(getLevel());
	text += " Lives: " + std::to_string(getLives());
	text += " Hlth: " + std::to_string(10 * player->getHealth()); text += "%";
	text += " Wtr: " + std::to_string(player->getWater());
	text += " Gld: " + std::to_string(player->getNuggets());
	text += " Oil Left: ???"; //EDIT THIS LATER!!!!!!!!!!!!!!!!!!!
	text += " Sonar: " + std::to_string(player->getSonar());
	text += " Scr: " + std::to_string(getScore());

	setGameStatText(text);
}

void StudentWorld::setUpIce()
{
	for (int x{}; x < 60; ++x)
	{
		
		for (int y{}; y < 60; ++y)
		{
			if (x >= 30 && x <= 33 && y > 4)
				continue;
			ice.push_back(new Ice(x, y));
		}
	}
}

void StudentWorld::deleteIce()
{
	for (auto iter = ice.begin(); iter != ice.end(); ++iter)
	{
		if (*iter != nullptr)
		{
			ice.erase(iter);
			iter = ice.begin();
		}
	}
}

std::vector<Ice*>* StudentWorld::getIce()
{
	return &ice;
}