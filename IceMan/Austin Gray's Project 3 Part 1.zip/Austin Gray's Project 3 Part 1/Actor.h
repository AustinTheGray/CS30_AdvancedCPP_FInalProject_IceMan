#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class StudentWorld;


class Actor : public GraphObject
{
public:
	Actor(int ID, int start_X, int start_Y, StudentWorld* wrld = nullptr, Direction d = right, double size = 1.0, unsigned int depth = 0)
		: GraphObject(ID, start_X, start_Y, d, size, depth),
		world(wrld)
	{};
	virtual void doSomething() { return; };
	virtual StudentWorld* getWorld(); 


private:
	StudentWorld* world;
	
};


class Ice : public Actor
{
public:
	Ice(int start_X, int start_Y)
		:Actor(IID_ICE, start_X, start_Y, nullptr, none, .25, 3)
	{
		setVisible(true);
	};
	virtual void doSomething();


	~Ice() { };
private:
};

class IceMan : public Actor
{
public:
	IceMan(StudentWorld* wrld)
		: Actor(IID_PLAYER, 30, 60, wrld, right, 1.0, 0U),
		hp(10),
		water(5),
		sonar(1),
		nuggets(0)
		//world(nullptr)
		{
		
		setVisible(true);
	};

	int getHealth();
	int getWater();
	int getSonar();
	int getNuggets();
	
	virtual void doSomething();
	void CheckIceCollision();
	
	~IceMan() {

	};
private:
	int hp;
	int water;
	int sonar;
	int nuggets;
};



#endif // ACTOR_H_
